<aside class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
      <div class="logo-icon">
        <img src="assets/images/logo-icon.png" class="logo-img" alt="">
      </div>
      <div class="logo-name flex-grow-1">
        <img style="width: 100px" src="{{ asset('assets/images/logo_kasool.png') }}" alt="">

      </div>
      <div class="sidebar-close">
        <span class="material-icons-outlined">close</span>
      </div>
    </div>
    <div class="sidebar-nav">
        <!--navigation-->
        <ul class="metismenu" id="sidenav">
          <li>
            {{--  <a href="javascript:;" class="has-arrow">
              <div class="parent-icon"><i class="material-icons-outlined">home</i>
              </div>
              <div class="menu-title">Dashboard</div>
            </a>  --}}
            <ul>
              <li><a href="{{ route('roles_page') }}"><i class="material-icons-outlined">arrow_right</i>Roles</a>
              </li>
              {{--  <li><a href="{{ route('permissions_page') }}"><i class="material-icons-outlined">arrow_right</i>Permissions</a>  --}}
              </li>
              <li><a href="{{ route('admins_page') }}"><i class="material-icons-outlined">arrow_right</i>Admins</a>
              </li>
            </ul>
          </li>
          <li>
            {{--  <a href="javascript:;" class="has-arrow">
              <div class="parent-icon"><i class="material-icons-outlined">widgets</i>
              </div>
              <div class="menu-title">Widgets</div>
            </a>  --}}
            <ul>
              <li>
                <a href="{{ route('categories_page') }}"><i class="material-icons-outlined">arrow_right</i>categories</a>
              </li>
              <li>
                <a href="{{ route('services_page') }}"><i class="material-icons-outlined">arrow_right</i>Services</a>
              </li>
              <li>
                <a href="{{ route('asks_page') }}"><i class="material-icons-outlined">arrow_right</i>Asks</a>
              </li>
              <li>
                <a href="{{ route('settings_page') }}"><i class="material-icons-outlined">arrow_right</i>settings</a>
              </li>
              <li>
                <a href="{{ route('reports_page') }}"><i class="material-icons-outlined">arrow_right</i>Reports</a>
              </li>
              <li>
                <a href="{{ route('orders') }}"><i class="material-icons-outlined">arrow_right</i>Orders</a>
              </li>
              <li>
                <a href="{{ route('gifts_page') }}"><i class="material-icons-outlined">arrow_right</i>Gifts</a>
              </li>
              <li>
                <a href="{{ route('deliveries_page') }}"><i class="material-icons-outlined">arrow_right</i>Deliveries</a>
              </li>
            </ul>
          </li>

         </ul>
        <!--end navigation-->
    </div>
  </aside>
